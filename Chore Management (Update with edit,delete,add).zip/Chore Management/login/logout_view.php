<?php

//start the session
session_start();

//unsetting the two session id in login
unset($_SESSION['pid']);
unset($_SESSION['rid']);

// Redirect to login_view page 
header("Location:../login/login_view.php");
exit();

