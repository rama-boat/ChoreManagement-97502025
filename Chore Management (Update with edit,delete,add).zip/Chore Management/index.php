

<?php
//to redirect to login page

header("location: login/login_view.php");

?>