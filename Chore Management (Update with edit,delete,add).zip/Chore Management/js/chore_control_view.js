
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('addchore').addEventListener('submit', function(event) {
        var choreName = document.getElementById('create_chore').value;
        var regex = /[A-Za-z]+$/;
        if (!regex.test(choreName)) {
            alert('Please enter a valid chore name (letters, spaces, hyphens, and apostrophes only)');
            event.preventDefault(); // Prevent form submission
        }
    });
});