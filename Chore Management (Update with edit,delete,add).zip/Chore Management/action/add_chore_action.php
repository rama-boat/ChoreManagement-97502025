<?php
// Include a connection file
include "../settings/connection.php";

//collection of data
if(isset($_POST["createChore"])){
    $chore_name = mysqli_real_escape_string( $con, $_POST["Create_chore"]);
   



    //write a query
    $sql_query = "INSERT INTO chores (chorename) VALUE ('$chore_name')";

    // check if query worked
    if ($con->query($sql_query) === true) {
        echo "Chore created successfully!";
        header("Location:../admin/chore_control_view.php");

    } else {
    //echo error 
        echo "Error: " ;
    }

    //close database connection
    $con->close();

}








?>