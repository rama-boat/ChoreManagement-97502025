<?php
// Include a connection file
include "../settings/connection.php";

//check for get url
if (isset($_GET['key'])) {

    //retrieve id
    $get_id = $_GET['key'];
  

    //perform delete query
    $delete_query= "DELETE FROM chores WHERE cid =$get_id";

    //check if executed
    if(mysqli_query($con, $delete_query)) {
        echo " Chore deleted successfully";
        header("Location:../admin/chore_control_view.php");
    } else {
        echo "Could not delete record".mysqli_error($con);
        
    }

    //Close the connection
    mysqli_close($con);
        
} else {
        header("Location:../admin/chore_control_view.php");
        exit;
}


?>