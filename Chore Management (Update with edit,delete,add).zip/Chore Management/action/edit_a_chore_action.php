<?php
// Include a connection file
include "../settings/connection.php";

//collection of data
if(isset($_POST["editChore"])){
    $chore_name = mysqli_real_escape_string( $con, $_POST["e_chore"]);
   



    //write a query
     $edit_query = "UPDATE chores SET chorename='$chore_name'";

    // check if query worked
     if(mysqli_query($con, $edit_query)) {
        echo " Chore updated successfully";
        header("Location:../admin/chore_control_view.php");
     } else {
        echo "Could not edit record".mysqli_error($con);
        
    }

    //close database connection
    $con->close();

}








?>