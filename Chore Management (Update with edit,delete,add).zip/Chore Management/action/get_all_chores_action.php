<?php
//include a connection file
include "../settings/connection.php";


//function to return result of SELECT query
function getAllChores(){
    global $con;

    // SELECT query
    $sql= "SELECT * FROM chores"; 

    // execute the query using global connection
    $result=mysqli_query($con,$sql);


    //Check if query was successful
    if ($result) {
        $chores=mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $chores;
        
        
    } else {
        //echo error 
        echo "Error: " . mysqli_error($con);

    }


}

?>