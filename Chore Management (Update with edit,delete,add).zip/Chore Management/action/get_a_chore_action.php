<?php
//include the connection file
include("../settings/connection.php");

//function to return one chore based on id
function getAChore($cid){
    global $con;

    // SELECT query
    $sql= "SELECT * FROM chores WHERE cid = $cid"; 
    echo "hello";
    
    

     // execute the query using global connection
     $result=mysqli_query($con,$sql);


    //Check if query was successful
    if ($result) {
        $a_chore=mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $a_chore;

        
        
    } else {
        //echo error 
        echo "Error: " . mysqli_error($con);

    }
}

?>