<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/manage_chores.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="../js/manage.js"></script>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <ul>
                <li>
                    <a href="#">
                        <i class="fa-solid fa-broom"></i>
                        <div class="title">Chore Management</div>
                    </a>
                </li>
                <li>
                    <a href="../view/welcome_dashboard.php">
                        <i class="fa-sharp fa-solid fa-house"></i>
                        <div class="title">Dashboard</div>
                    </a>
                </li>
                <li>
                    <a href="../view/manage_chores.php">
                        <i class="fa-solid fa-list-check"></i>
                        <div class="title">Manage Chores</div>
                    </a>
                </li>
                <li>
                    <a href="../admin/AssignPage.php">
                        <i class="fa-regular fa-clipboard"></i>
                        <div class="title">Assign Chores</div>
                    </a>
                </li>
                <li>
                    <a href="../login/login_view.php">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i>
                        <div class="title">Log Out</div>
                    </a>
                </li>
            </ul>
        </div>

        <div class="main">
            <div class="top-bar">
                <div class="search">
                    <input type="text" name="search" placeholder="Search here">
                    <label for="search"><i class="fas fa-search"></i></label>
                </div>
                <div class="user">
                    <img src="rew.jpg" alt="">
                </div>
            </div>
            
            <div class="tables">
                    <div class="last-appointments">
                        <div class="heading">
                            <h2>Recently Completed Chores</h2>
                            <a href="#" class="btn">View All</a>
                        </div>
                        <table class="appointments">
                            <thead>
                                <td>Chore Name</td>
                                <td>Assigned By</td>
                                <td>Date Finished</td>
                                <td>Actions</td>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Laundry</td>
                                    <td>Father</td>
                                    <td>23/07/24</td>
                                    <td>
                                        <i class="far fa-eye"></i>
                                        <i class="far fa-edit"></i>
                                        <i class="far fa-trash-alt"></i>
                                    </td>

                                </tr>
                                <tr>
                                    <td>Car Wash</td>
                                    <td>Mother</td>
                                    <td>24/07/24</td>
                                    <td>
                                        <i class="far fa-eye"></i>
                                        <i class="far fa-edit"></i>
                                        <i class="far fa-trash-alt"></i>
                                    </td>

                                </tr>
                                <tr>
                                    <td>Dish Wash</td>
                                    <td>Mother</td>
                                    <td>25/07/24</td>
                                    <td>
                                        <i class="far fa-eye"></i>
                                        <i class="far fa-edit"></i>
                                        <i class="far fa-trash-alt"></i>
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>

   

</body>
</html>