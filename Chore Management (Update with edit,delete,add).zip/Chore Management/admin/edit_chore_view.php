<?php
include("../settings/core.php");
include("../action/get_a_chore_action.php");



//check for GET url
if (isset($_GET['keys'])) {

    //retrieve id from get url
     $get_cid = $_GET['keys'];

    //call function created in get_a_chore_action
     $ret_var = getAChore($get_cid);
} else {
    header("Location:../admin/chore_control_view.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Chores</title>
  <link rel="stylesheet" type="text/css" href="../css/edit_chore_view.css">
  
</head>
<body>
<div class="edit">
    
    <!-- Form -->
    <form  action="../action/edit_a_chore_action.php" method="post" name="edit_chore">
    <h1>Edit Chore</h1>
             <!-- name -->
			<input type="text" id="create_chore" placeholder= "Name of Chore" name="e_chore" value= "<?php '$ret_var'?>" pattern="[a-zA-Z]+(['\- ][a-zA-Z]+)*" required>
			<!-- Submit button -->
            <button type="submit" name="editChore" id="subBtn">Edit Chore</button>
		</form>
  </div>



</body>
</html>