<?php 
include "../settings/core.php";
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../css/chore_control_view.css">
    <title>Create Chores</title>
</head>
<body>
	<h1>Create Chore</h1>
	<section id="createChoreForm">
        <hr>
		
		<form  action="../action/add_chore_action.php" method="post" name="addchore">
             <!-- name -->
			<input type="text" id="create_chore" placeholder= "Name of Chore" name="Create_chore"  pattern="[a-zA-Z]+(['\- ][a-zA-Z]+)*" required>
			<!-- Submit button -->
            <button type="submit" name="createChore" id="subBtn">Add a Chore</button>
		</form>
		
	</section>

	<section id="choreList">
        <h2>Chore List</h2>
        <a href="#" class="btn">Assign chore</a>
        <?php
        include "../functions/chore_fxn.php";
        ?>
    </section> 

</body>
</html>









